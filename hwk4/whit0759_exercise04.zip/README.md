# CSCI 5481: Homework 4

# Professor Knights
# Author: Christopher White
# Date: November 22, 2018

This python file should be run on the command line in the same directory as the 'Homework_4_seqs.fna' file.

    % python white_exercise04.py

The script will automatically process the 'Homework_4_seqs.fna' file to generate 3 outputs.

1.  The first output will be the CSV file of conserved value versus position for the whole length of the sequence
2.  The second output will be a PDF file with the plot of the variation versus position.
3.  The last output is a CSV file with the variable regions found. The first column is the start postion and the last column is the end position.

